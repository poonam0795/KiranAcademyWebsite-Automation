package Excel_File;

import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelData {
	public static Object[][] Excelfile() throws IOException {
		DataFormatter df = new DataFormatter();
		// FileInputStream file = new FileInputStream(
		// "C:\\Users\\admin\\eclipse-workspace\\TestNG_Framework\\ExcelFiles\\Login_page_data.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(
				"C:\\Users\\admin\\eclipse-workspace\\JavaByKiran_Project\\ExcelFiles\\Login_page_data.xlsx");
		XSSFSheet sheet = workbook.getSheet("Sheet1");
		int Num_row = sheet.getLastRowNum();
		int Num_column = sheet.getRow(0).getLastCellNum();
		Object obj[][] = new Object[Num_row + 1][Num_column];
		for (int i = 0; i <= Num_row; i++) {
			XSSFRow row = sheet.getRow(i);
			for (int j = 0; j < Num_column; j++) {
				XSSFCell cell = row.getCell(j);
				obj[i][j] = df.formatCellValue(cell);
			}

		}
		return obj;
	}

}
