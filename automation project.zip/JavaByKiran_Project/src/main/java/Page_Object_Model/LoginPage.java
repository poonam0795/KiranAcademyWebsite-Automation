package Page_Object_Model;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "email")
	WebElement txtEmail;
	@FindBy(id = "password")
	WebElement txtpassword;
	@FindBy(xpath = "//*[@id=\"form\"]/div[3]/div/button")
	WebElement btnSignIn;
	@FindBy(linkText = "Register a new membership")
	WebElement RegisternewMember;

	public void email(String mail) {
		txtEmail.sendKeys(mail);
	}

	public void password(String pass) {
		txtpassword.sendKeys(pass);
	}

	public void SignIn() {
		btnSignIn.click();
	}

	public void registerNewMember() {
		RegisternewMember.click();
	}
}
