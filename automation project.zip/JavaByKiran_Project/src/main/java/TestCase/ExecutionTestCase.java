package TestCase;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Base_Package.Login_Setup;
import Excel_File.ExcelData;

public class ExecutionTestCase extends Login_Setup {

	@Test(dataProvider = "TData")
	void LoginTestCases(String username, String Password, String isuccessful) {
		WebElement EmailError = driver.findElement(By.id("email_error"));
		WebElement passwordError = driver.findElement(By.id("password_error"));
		if (isuccessful.contains("1")) {
			lp.email(username);
			lp.password(Password);
			lp.SignIn();
			Assert.assertTrue(driver.getTitle().equals("JavaByKiran | Dashboard"));
		} else {
			lp.email(username);
			lp.password(Password);
			lp.SignIn();

			if (EmailError.isDisplayed()) {
				Assert.assertTrue(true);
			} else if (passwordError.isDisplayed()) {
				Assert.assertTrue(true);
			} else if (username.isEmpty()) {
				String text1 = driver.findElement(By.xpath("//*[@id=\"email_error\"]")).getText();
				Assert.assertEquals(text1, "Please enter email.");

			} else if (Password.isEmpty()) {
				String text2 = driver.findElement(By.xpath("//*[@id=\"password_error\"]")).getText();
				Assert.assertEquals(text2, "Please enter password.");

			}
		}

	}

	@DataProvider(name = "TData")
	public Object[][] data() throws IOException {
		Object td[][] = ExcelData.Excelfile();
		return td;
	}

}
