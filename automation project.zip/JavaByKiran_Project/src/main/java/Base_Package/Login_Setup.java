package Base_Package;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import Page_Object_Model.LoginPage;

public class Login_Setup {
	public WebDriver driver;
	public LoginPage lp;

	@BeforeMethod
	public void setup() {
		driver = new ChromeDriver();
		driver.get(
				"file:///C:/Users/admin/Downloads/Selenium%20Softwares/Selenium%20Softwares/Offline%20Website/index.html");
		lp = new LoginPage(driver);

	}

	@AfterMethod
	public void teardown() {
		driver.quit();
	}

}
